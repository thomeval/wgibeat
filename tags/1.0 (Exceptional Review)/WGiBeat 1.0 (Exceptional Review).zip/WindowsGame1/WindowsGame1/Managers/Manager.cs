﻿namespace WGiBeat.Managers
{
    public abstract class Manager
    {
        public LogManager Log { get; set; }
    }
}
