﻿namespace WGiBeat
{
    public enum GameType
    {
        NORMAL = 0,
        COOPERATIVE = 1,
        TEAM = 2,
        VS_CPU = 3,
        SYNC = 4,
       // BATTLE = 5,
        COUNT = 5
    }
}