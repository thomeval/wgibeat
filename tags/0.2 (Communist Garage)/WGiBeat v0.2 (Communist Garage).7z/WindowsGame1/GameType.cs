﻿namespace WGiBeat
{
    public enum GameType
    {
        NORMAL = 0,
        COOPERATIVE = 1,
        TEAM = 2,
       // SYNC = 3,
       // VS_CPU = 4,
       // BATTLE = 5,
        COUNT = 3
    }
}